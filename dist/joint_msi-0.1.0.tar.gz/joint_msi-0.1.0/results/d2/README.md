# JOINT d2 reference run

This directory contains a complete JOINT run on the real d2 reference data from
`/Users/mac/Desktop/nanoMap/nanoMAP_figures/Figure5/5A-C`.

## Reproduce the run

```bash
export JOINT_DATA_ROOT=/Users/mac/Desktop/nanoMap/nanoMAP_figures/Figure5/5A-C
joint run --config configs/d2.yaml --overwrite
python scripts/render_d2_figures.py
```

The pipeline uses the real image-based laser segmentation settings from
`laserPoints-d2.ipynb`, including the d2 crop, rolling-variance row detection, exclusion at
column 1610, and the d2 manual merge rules.

## Results

| Stage or object | Result |
| --- | ---: |
| MSI observations after preprocessing | 1,760 |
| Raw laser regions before d2 exclusions/merges | 1,707 |
| Active registered laser observations | 1,480 (40 rows × 37 columns) |
| Cell observations | 2,936 |
| Cells with quantified signal | 1,919 |
| Accepted laser-to-cell mappings | 2,274 |
| Positive-mean metabolite features | 360 |

The root `joint-final.h5ad` contains 2,936 cells × 360 features, spatial coordinates, PCA,
neighbors, Leiden clusters, and QC outlier calls. The original notebook's UMAP is rendered as
`figures/08_umap.png`; each positive-mean feature has a spatial map in `figures/metabolites/`.

## Key files

- `joint-final.h5ad` — final integrated AnnData object.
- `preprocessing/msi.h5ad` — preprocessed MSI input (1,760 × 360).
- `segmentation/laser_labels.npy` — image-sized laser label array.
- `segmentation/laser_regions.csv` — laser-region measurements and row/column assignments.
- `registration/laser.h5ad` — registered laser observations (1,480 × 360).
- `quantification/cells.h5ad` — cell-level laser-to-cell quantification.
- `qc/cells_qc.h5ad` — spectral QC and outlier calls.
- `analysis/cells_analyzed.h5ad` — PCA/neighbors/Leiden analysis artifact.
- `d2-figures-manifest.json` — complete list of generated PNGs and source/count metadata.

## Review figures

![Laser segmentation](figures/02_laser_segmentation_crop.png)

![Registration overlay](figures/03_registration_overlay.png)

![Cell segmentation](figures/04_cell_segmentation_crop.png)

![Cluster map](figures/06_cluster_map.png)

![UMAP](figures/08_umap.png)

![Representative metabolite maps](figures/metabolites/contact_sheet_representative.png)

There are 360 individual metabolite maps, named with their feature order and m/z feature name,
for example `figures/metabolites/001_m170.png`.
